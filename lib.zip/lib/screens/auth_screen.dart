import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/database_service.dart';
// Import AppColors from main
class _C {
  static const Color bg = Color(0xFFF4F7FC);
  static const Color mint = Color(0xFF00D4AA);
  static const Color mintLight = Color(0xFF5BFFD4);
  static const Color mintSoft = Color(0xFFE8FFF7);
  static const Color sky = Color(0xFF38BDF8);
  static const Color skyDeep = Color(0xFF0EA5E9);
  static const Color textDark = Color(0xFF1A1F36);
  static const Color textMedium = Color(0xFF4A5568);
  static const Color textLight = Color(0xFF94A3B8);
  static const Color textHint = Color(0xFFCBD5E1);
  static const Color border = Color(0xFFE2E8F0);
  static const Color coral = Color(0xFFFF6B6B);
  static const Color purple = Color(0xFF8B5CF6);
}
class AuthScreen extends StatefulWidget {
  const AuthScreen({Key? key}) : super(key: key);
  @override
  _AuthScreenState createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> with TickerProviderStateMixin {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _nameController = TextEditingController();
  final _dbService = DatabaseService();
  bool isLogin = true;
  bool isLoading = false;
  bool _obscurePassword = true;
  bool _emailFocused = false;
  bool _passFocused = false;
  bool _nameFocused = false;
  late AnimationController _bgAnimController;
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  late Animation<double> _pulseAnim;
  @override
  void initState() {
    super.initState();
    _bgAnimController = AnimationController(
      vsync: this, duration: const Duration(seconds: 10),
    )..repeat(reverse: true);
    _fadeController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1200),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _pulseController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _slideController = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 800),
    );
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.3), end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));
    _fadeController.forward();
    _slideController.forward();
  }
  @override
  void dispose() {
    _bgAnimController.dispose(); _fadeController.dispose();
    _pulseController.dispose(); _slideController.dispose();
    _emailController.dispose(); _passwordController.dispose();
    _nameController.dispose();
    super.dispose();
  }
  void _toggleMode() {
    setState(() => isLogin = !isLogin);
    _slideController.reset();
    _slideController.forward();
  }
  Future<void> _submit() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();
    final name = _nameController.text.trim();
    if (email.isEmpty || password.isEmpty) { _showError('Заполните все поля'); return; }
    if (!isLogin && name.isEmpty) { _showError('Введите ваше имя'); return; }
    setState(() => isLoading = true);
    try {
      if (isLogin) {
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password);
      } else {
        UserCredential cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: password);
        await cred.user?.updateDisplayName(name);
        await _dbService.createUserData(name, email);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Row(children: [
              const Icon(Icons.check_circle_outline, color: Colors.white, size: 20),
              const SizedBox(width: 12),
              Text('Добро пожаловать, $name! 🎉'),
            ]),
            backgroundColor: _C.mint,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            margin: const EdgeInsets.all(20),
          ));
        }
      }
    } on FirebaseAuthException catch (e) {
      String msg = 'Произошла ошибка';
      switch (e.code) {
        case 'user-not-found': msg = 'Пользователь не найден'; break;
        case 'wrong-password': msg = 'Неверный пароль'; break;
        case 'email-already-in-use': msg = 'Email уже зарегистрирован'; break;
        case 'weak-password': msg = 'Пароль слишком слабый (мин. 6 символов)'; break;
        case 'invalid-email': msg = 'Некорректный email'; break;
        case 'too-many-requests': msg = 'Слишком много попыток. Попробуйте позже'; break;
        case 'network-request-failed': msg = 'Нет подключения к интернету'; break;
        default: msg = e.message ?? 'Ошибка авторизации';
      }
      _showError(msg);
    } catch (e) {
      _showError(e.toString());
    }
    if (mounted) setState(() => isLoading = false);
  }
  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        const Icon(Icons.error_outline, color: Colors.white, size: 20),
        const SizedBox(width: 12),
        Expanded(child: Text(msg, style: const TextStyle(fontSize: 14))),
      ]),
      backgroundColor: _C.coral,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.all(20),
      duration: const Duration(seconds: 3),
    ));
  }
  Future<void> _resetPassword() async {
    final email = _emailController.text.trim();
    if (email.isEmpty) { _showError('Введите email для сброса пароля'); return; }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Row(children: [
            const Icon(Icons.check_circle_outline, color: Colors.white, size: 20),
            const SizedBox(width: 12),
            Expanded(child: Text('Письмо отправлено на $email')),
          ]),
          backgroundColor: _C.mint,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          margin: const EdgeInsets.all(20),
        ));
      }
    } catch (e) {
      _showError('Ошибка отправки: ${e.toString()}');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          _buildAnimatedBackground(),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: FadeTransition(
                  opacity: _fadeAnim,
                  child: SlideTransition(
                    position: _slideAnim,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildLogo(),
                        const SizedBox(height: 40),
                        _buildFormCard(),
                        const SizedBox(height: 24),
                        _buildSocialLogin(),
                        const SizedBox(height: 20),
                        _buildToggleMode(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  Widget _buildAnimatedBackground() {
    return AnimatedBuilder(
      animation: _bgAnimController,
      builder: (context, child) {
        double t = _bgAnimController.value;
        return Stack(
          children: [
            // Soft mint gradient blob top-right
            Positioned(
              top: -100 + (40 * math.sin(t * math.pi)),
              right: -80 + (25 * math.cos(t * math.pi)),
              child: Container(
                width: 350, height: 350,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    _C.mint.withOpacity(0.12),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
            // Soft sky gradient blob bottom-left
            Positioned(
              bottom: -120 + (30 * math.cos(t * math.pi)),
              left: -90 + (20 * math.sin(t * math.pi)),
              child: Container(
                width: 400, height: 400,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    _C.sky.withOpacity(0.10),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
            // Purple accent blob center-right
            Positioned(
              top: MediaQuery.of(context).size.height * 0.35,
              right: -60 + (15 * math.sin(t * math.pi * 2)),
              child: Container(
                width: 200, height: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    _C.purple.withOpacity(0.06),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
            // Floating dots
            ...List.generate(6, (i) {
              double offset = (i * 0.3 + t) % 1.0;
              return Positioned(
                top: 100 + (i * 120.0) + (20 * math.sin(offset * math.pi * 2)),
                left: 30 + (i * 55.0) % MediaQuery.of(context).size.width,
                child: Container(
                  width: 4 + (i % 3) * 2.0,
                  height: 4 + (i % 3) * 2.0,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.mint.withOpacity(0.15 + 0.1 * math.sin(offset * math.pi)),
                  ),
                ),
              );
            }),
          ],
        );
      },
    );
  }
  Widget _buildLogo() {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (context, child) {
            return Transform.scale(
              scale: _pulseAnim.value,
              child: Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [_C.mint, _C.sky],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: _C.mint.withOpacity(0.3 * _pulseAnim.value),
                      blurRadius: 30, spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Icon(Icons.favorite, color: Colors.white, size: 44),
              ),
            );
          },
        ),
        const SizedBox(height: 20),
        const Text(
          'PULSECHECK',
          style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: 6, color: _C.textDark),
        ),
        const SizedBox(height: 4),
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [_C.mint, _C.sky],
          ).createShader(bounds),
          child: const Text(
            'HEALTH ASSISTANT',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 4, color: Colors.white),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          isLogin ? 'Войдите в свой аккаунт' : 'Создайте новый аккаунт',
          style: TextStyle(fontSize: 15, color: _C.textLight),
        ),
      ],
    );
  }
  Widget _buildFormCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.85),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _C.mint.withOpacity(0.12)),
            boxShadow: [
              BoxShadow(color: _C.textDark.withOpacity(0.06), blurRadius: 30, offset: const Offset(0, 10)),
              BoxShadow(color: _C.mint.withOpacity(0.04), blurRadius: 40, offset: const Offset(0, 20)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTabSwitcher(),
              const SizedBox(height: 28),
              AnimatedSize(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeInOut,
                child: !isLogin
                    ? Column(children: [
                        _buildTextField(
                          controller: _nameController, label: 'Имя', hint: 'Введите ваше имя',
                          icon: Icons.person_outline_rounded,
                          isFocused: _nameFocused,
                          onFocusChange: (f) => setState(() => _nameFocused = f),
                        ),
                        const SizedBox(height: 16),
                      ])
                    : const SizedBox.shrink(),
              ),
              _buildTextField(
                controller: _emailController, label: 'Email', hint: 'example@mail.com',
                icon: Icons.email_outlined, keyboardType: TextInputType.emailAddress,
                isFocused: _emailFocused,
                onFocusChange: (f) => setState(() => _emailFocused = f),
              ),
              const SizedBox(height: 16),
              _buildTextField(
                controller: _passwordController, label: 'Пароль', hint: '••••••••',
                icon: Icons.lock_outline_rounded, obscure: _obscurePassword,
                isFocused: _passFocused,
                onFocusChange: (f) => setState(() => _passFocused = f),
                suffix: IconButton(
                  icon: Icon(
                    _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    color: _C.textHint, size: 20,
                  ),
                  onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                ),
              ),
              if (isLogin) ...[
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: _resetPassword,
                    child: Text('Забыли пароль?', style: TextStyle(fontSize: 13, color: _C.mint, fontWeight: FontWeight.w500)),
                  ),
                ),
              ],
              const SizedBox(height: 28),
              _buildSubmitButton(),
            ],
          ),
        ),
      ),
    );
  }
  Widget _buildTabSwitcher() {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.border.withOpacity(0.5)),
      ),
      child: Row(children: [
        _tabButton('Вход', isLogin, () { if (!isLogin) _toggleMode(); }),
        _tabButton('Регистрация', !isLogin, () { if (isLogin) _toggleMode(); }),
      ]),
    );
  }
  Widget _tabButton(String label, bool active, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300), curve: Curves.easeInOut,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: active
                ? const LinearGradient(colors: [_C.mint, _C.sky])
                : null,
            boxShadow: active ? [BoxShadow(color: _C.mint.withOpacity(0.25), blurRadius: 8)] : [],
          ),
          child: Center(
            child: Text(label, style: TextStyle(
              fontSize: 14, fontWeight: FontWeight.w600,
              color: active ? Colors.white : _C.textLight,
            )),
          ),
        ),
      ),
    );
  }
  Widget _buildTextField({
    required TextEditingController controller,
    required String label, required String hint, required IconData icon,
    bool obscure = false, TextInputType keyboardType = TextInputType.text,
    required bool isFocused, required Function(bool) onFocusChange, Widget? suffix,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: _C.textMedium, letterSpacing: 0.5)),
        const SizedBox(height: 8),
        Focus(
          onFocusChange: onFocusChange,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: isFocused ? _C.mintSoft : _C.bg,
              border: Border.all(
                color: isFocused ? _C.mint.withOpacity(0.5) : _C.border,
                width: isFocused ? 1.5 : 1,
              ),
              boxShadow: isFocused
                  ? [BoxShadow(color: _C.mint.withOpacity(0.1), blurRadius: 15)]
                  : [],
            ),
            child: TextField(
              controller: controller, obscureText: obscure, keyboardType: keyboardType,
              style: const TextStyle(color: _C.textDark, fontSize: 15, fontWeight: FontWeight.w500),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(color: _C.textHint, fontSize: 14),
                prefixIcon: Container(
                  margin: const EdgeInsets.only(left: 4),
                  child: Icon(icon, color: isFocused ? _C.mint : _C.textLight, size: 20),
                ),
                suffixIcon: suffix,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              ),
            ),
          ),
        ),
      ],
    );
  }
  Widget _buildSubmitButton() {
    return GestureDetector(
      onTap: isLoading ? null : _submit,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: double.infinity, height: 56,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: isLoading
                ? [_C.mint.withOpacity(0.4), _C.sky.withOpacity(0.4)]
                : [_C.mint, _C.sky],
          ),
          boxShadow: isLoading ? [] : [
            BoxShadow(color: _C.mint.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 8)),
          ],
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
              : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(isLogin ? Icons.login_rounded : Icons.person_add_rounded, color: Colors.white, size: 20),
                  const SizedBox(width: 10),
                  Text(
                    isLogin ? 'ВОЙТИ' : 'СОЗДАТЬ АККАУНТ',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: Colors.white),
                  ),
                ]),
        ),
      ),
    );
  }
  Widget _buildSocialLogin() {
    return Column(children: [
      Row(children: [
        Expanded(child: Container(height: 1, color: _C.border)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text('или', style: TextStyle(fontSize: 13, color: _C.textHint)),
        ),
        Expanded(child: Container(height: 1, color: _C.border)),
      ]),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        _socialButton(Icons.g_mobiledata_rounded, 'Google', const Color(0xFFEA4335)),
        const SizedBox(width: 16),
        _socialButton(Icons.apple_rounded, 'Apple', _C.textDark),
      ]),
    ]);
  }
  Widget _socialButton(IconData icon, String label, Color iconColor) {
    return GestureDetector(
      onTap: () => _showError('$label вход скоро будет доступен'),
      child: Container(
        width: 130, height: 52,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Colors.white,
          border: Border.all(color: _C.border),
          boxShadow: [BoxShadow(color: _C.textDark.withOpacity(0.04), blurRadius: 8)],
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: iconColor, size: 24),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: _C.textMedium, fontSize: 13, fontWeight: FontWeight.w500)),
        ]),
      ),
    );
  }
  Widget _buildToggleMode() {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(
        isLogin ? 'Нет аккаунта? ' : 'Уже есть аккаунт? ',
        style: TextStyle(color: _C.textLight, fontSize: 14),
      ),
      GestureDetector(
        onTap: _toggleMode,
        child: ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [_C.mint, _C.sky],
          ).createShader(bounds),
          child: Text(
            isLogin ? 'Регистрация' : 'Войти',
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white),
          ),
        ),
      ),
    ]);
  }
}
