import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DatabaseService {
  String? get _currentUid => FirebaseAuth.instance.currentUser?.uid;

  final CollectionReference _pulseCollection =
      FirebaseFirestore.instance.collection('pulse_history');

  // ✅ Create user profile on registration
  Future<void> createUserData(String name, String email) async {
    final uid = _currentUid;
    if (uid == null) return;

    await FirebaseFirestore.instance.collection('users').doc(uid).set({
      'name': name,
      'email': email,
      'createdAt': FieldValue.serverTimestamp(),
      'role': 'patient',
    });
  }

  // ✅ Get user profile data
  Future<Map<String, dynamic>?> getUserData() async {
    final uid = _currentUid;
    if (uid == null) return null;

    final doc =
        await FirebaseFirestore.instance.collection('users').doc(uid).get();
    return doc.data();
  }

  // ✅ Update user profile
  Future<void> updateUserData(Map<String, dynamic> data) async {
    final uid = _currentUid;
    if (uid == null) return;

    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .update(data);
  }

  // ✅ Save pulse measurement
  Future<void> savePulseData(int bpm, int minBpm, int maxBpm) async {
    final uid = _currentUid;
    if (uid == null) {
      print("Ошибка: Пользователь не найден");
      return;
    }

    try {
      await _pulseCollection.add({
        'uid': uid,
        'bpm': bpm,
        'min': minBpm,
        'max': maxBpm,
        'type': 'pulse',
        'timestamp': FieldValue.serverTimestamp(),
      });
      print("Данные пульса сохранены!");
    } catch (e) {
      print("Ошибка сохранения пульса: $e");
      rethrow;
    }
  }

  // ✅ Save breathing measurement
  Future<void> saveBreathingData(int breathsPerMin, int totalBreaths, int durationSec) async {
    final uid = _currentUid;
    if (uid == null) return;

    try {
      await FirebaseFirestore.instance.collection('breathing_history').add({
        'uid': uid,
        'breathsPerMin': breathsPerMin,
        'totalBreaths': totalBreaths,
        'durationSec': durationSec,
        'type': 'breathing',
        'timestamp': FieldValue.serverTimestamp(),
      });
      print("Данные дыхания сохранены!");
    } catch (e) {
      print("Ошибка сохранения дыхания: $e");
    }
  }

  // ✅ Get pulse history stream
  Stream<QuerySnapshot> getPulseHistory() {
    return _pulseCollection
        .where('uid', isEqualTo: _currentUid)
        .orderBy('timestamp', descending: true)
        .snapshots();
  }

  // ✅ Get all measurements (pulse + breathing) for profile
  Stream<QuerySnapshot> getAllMeasurements() {
    return _pulseCollection
        .where('uid', isEqualTo: _currentUid)
        .orderBy('timestamp', descending: true)
        .limit(20)
        .snapshots();
  }

  // ✅ Save medicine list
  Future<void> saveMedicineList(List<Map<String, dynamic>> medicines) async {
    final uid = _currentUid;
    if (uid == null) return;

    await FirebaseFirestore.instance
        .collection('medicines')
        .doc(uid)
        .set({'medicines': medicines, 'updatedAt': FieldValue.serverTimestamp()});
  }

  // ✅ Get medicine list
  Future<List<Map<String, dynamic>>> getMedicineList() async {
    final uid = _currentUid;
    if (uid == null) return [];

    final doc = await FirebaseFirestore.instance
        .collection('medicines')
        .doc(uid)
        .get();

    if (doc.exists && doc.data()?['medicines'] != null) {
      return List<Map<String, dynamic>>.from(doc.data()!['medicines']);
    }
    return [];
  }
}
