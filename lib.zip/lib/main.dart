import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:camera/camera.dart';
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'services/database_service.dart';
import 'screens/auth_screen.dart';
// ============================================================
// COLOR PALETTE — PulseCheck Medical Theme
// ============================================================
class AppColors {
  static const Color bg = Color(0xFFF4F7FC);
  static const Color cardBg = Colors.white;
  static const Color mint = Color(0xFF00D4AA);
  static const Color mintLight = Color(0xFF5BFFD4);
  static const Color mintSoft = Color(0xFFE8FFF7);
  static const Color sky = Color(0xFF38BDF8);
  static const Color skyDeep = Color(0xFF0EA5E9);
  static const Color skyLight = Color(0xFFE0F2FE);
  static const Color textDark = Color(0xFF1A1F36);
  static const Color textMedium = Color(0xFF4A5568);
  static const Color textLight = Color(0xFF94A3B8);
  static const Color textHint = Color(0xFFCBD5E1);
  static const Color border = Color(0xFFE2E8F0);
  static const Color borderLight = Color(0xFFF1F5F9);
  static const Color coral = Color(0xFFFF6B6B);
  static const Color coralLight = Color(0xFFFFE0E0);
  static const Color orange = Color(0xFFFF9F43);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color purpleLight = Color(0xFFF3EEFF);
}
// ============================================================
// MAIN ENTRY POINT
// ============================================================
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(const PulseCheckApp());
}
// ============================================================
// APP ROOT
// ============================================================
class PulseCheckApp extends StatelessWidget {
  const PulseCheckApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PulseCheck',
      theme: ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: AppColors.bg,
        primaryColor: AppColors.mint,
        fontFamily: 'SF Pro Display',
        colorScheme: const ColorScheme.light(
          primary: AppColors.mint,
          secondary: AppColors.sky,
          surface: AppColors.cardBg,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: IconThemeData(color: AppColors.textDark),
          titleTextStyle: TextStyle(
            color: AppColors.textDark,
            fontSize: 18,
            fontWeight: FontWeight.w700,
          ),
        ),
        pageTransitionsTheme: const PageTransitionsTheme(
          builders: {
            TargetPlatform.android: CupertinoPageTransitionsBuilder(),
            TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          },
        ),
      ),
      home: const AuthWrapper(),
    );
  }
}
// ============================================================
// AUTH WRAPPER — with fade transition
// ============================================================
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _SplashScreen();
        }
        if (snapshot.hasData && snapshot.data != null) {
          return const MainShell();
        }
        return const AuthScreen();
      },
    );
  }
}
// ============================================================
// SPLASH SCREEN — animated loading
// ============================================================
class _SplashScreen extends StatefulWidget {
  const _SplashScreen({Key? key}) : super(key: key);
  @override
  State<_SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<_SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnim;
  late Animation<double> _opacityAnim;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _scaleAnim = Tween<double>(begin: 0.9, end: 1.1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOutCubic),
    );
    _opacityAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return Transform.scale(
                  scale: _scaleAnim.value,
                  child: Opacity(
                    opacity: _opacityAnim.value,
                    child: Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [AppColors.mint, AppColors.sky],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.mint.withOpacity(0.4),
                            blurRadius: 30,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.favorite_rounded,
                        color: Colors.white,
                        size: 36,
                      ),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 28),
            const Text(
              'PULSECHECK',
              style: TextStyle(
                fontSize: 16,
                letterSpacing: 6,
                color: AppColors.textDark,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: 32,
              height: 32,
              child: CircularProgressIndicator(
                color: AppColors.mint,
                strokeWidth: 2.5,
                strokeCap: StrokeCap.round,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
// ============================================================
// MAIN SHELL WITH BOTTOM NAV — smooth page transitions
// ============================================================
class MainShell extends StatefulWidget {
  const MainShell({Key? key}) : super(key: key);
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> with TickerProviderStateMixin {
  int _currentIndex = 0;
  late final PageController _pageController;
  late AnimationController _bgAnimController;
  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _bgAnimController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat(reverse: true);
  }
  @override
  void dispose() {
    _pageController.dispose();
    _bgAnimController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          // Animated ambient gradients
          AnimatedBuilder(
            animation: _bgAnimController,
            builder: (context, _) {
              return Stack(
                children: [
                  Positioned(
                    top: -150 + 30 * math.sin(_bgAnimController.value * math.pi),
                    right: -100 + 20 * math.cos(_bgAnimController.value * math.pi),
                    child: Container(
                      width: 350,
                      height: 350,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [
                          AppColors.mint.withOpacity(0.08),
                          Colors.transparent,
                        ]),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: -120 + 25 * math.cos(_bgAnimController.value * math.pi),
                    left: -80 + 15 * math.sin(_bgAnimController.value * math.pi),
                    child: Container(
                      width: 300,
                      height: 300,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [
                          AppColors.sky.withOpacity(0.06),
                          Colors.transparent,
                        ]),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
          // Page view with smooth swiping
          PageView(
            controller: _pageController,
            physics: const NeverScrollableScrollPhysics(),
            children: const [
              HomePage(),
              DoctorsPage(),
              AIChatPage(),
              ProfilePage(),
            ],
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }
  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.textDark.withOpacity(0.04),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
        border: Border(
          top: BorderSide(
            color: AppColors.border.withOpacity(0.5),
            width: 0.5,
          ),
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _navItem(0, Icons.home_rounded, 'Главная'),
              _navItem(1, Icons.medical_services_rounded, 'Врачи'),
              _navItem(2, Icons.psychology_rounded, 'AI Чат'),
              _navItem(3, Icons.person_rounded, 'Профиль'),
            ],
          ),
        ),
      ),
    );
  }
  Widget _navItem(int index, IconData icon, String label) {
    final isSelected = _currentIndex == index;
    return GestureDetector(
      onTap: () {
        if (_currentIndex != index) {
          setState(() => _currentIndex = index);
          _pageController.animateToPage(
            index,
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeOutCubic,
          );
        }
      },
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.mintSoft : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedScale(
              scale: isSelected ? 1.15 : 1.0,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutBack,
              child: Icon(
                icon,
                color: isSelected ? AppColors.mint : AppColors.textLight,
                size: 24,
              ),
            ),
            const SizedBox(height: 4),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 250),
              style: TextStyle(
                color: isSelected ? AppColors.mint : AppColors.textLight,
                fontSize: 10,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                letterSpacing: 0.3,
              ),
              child: Text(label),
            ),
          ],
        ),
      ),
    );
  }
}
// ============================================================
// SOFT CARD WIDGET — with press animation
// ============================================================
class SoftCard extends StatefulWidget {
  final Widget child;
  final EdgeInsets? padding;
  final Color? color;
  final double borderRadius;
  final VoidCallback? onTap;
  final Color? borderColor;
  const SoftCard({
    Key? key,
    required this.child,
    this.padding,
    this.color,
    this.borderRadius = 20,
    this.onTap,
    this.borderColor,
  }) : super(key: key);
  @override
  State<SoftCard> createState() => _SoftCardState();
}
class _SoftCardState extends State<SoftCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _pressController;
  late Animation<double> _scaleAnim;
  @override
  void initState() {
    super.initState();
    _pressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scaleAnim = Tween<double>(begin: 1.0, end: 0.97).animate(
      CurvedAnimation(parent: _pressController, curve: Curves.easeInOut),
    );
  }
  @override
  void dispose() {
    _pressController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: widget.onTap != null ? (_) => _pressController.forward() : null,
      onTapUp: widget.onTap != null
          ? (_) {
              _pressController.reverse();
              widget.onTap!();
            }
          : null,
      onTapCancel: widget.onTap != null ? () => _pressController.reverse() : null,
      child: AnimatedBuilder(
        animation: _scaleAnim,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnim.value,
            child: child,
          );
        },
        child: Container(
          padding: widget.padding ?? const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: widget.color ?? Colors.white,
            borderRadius: BorderRadius.circular(widget.borderRadius),
            border: Border.all(
              color: widget.borderColor ?? AppColors.border.withOpacity(0.4),
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.textDark.withOpacity(0.04),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
              BoxShadow(
                color: AppColors.mint.withOpacity(0.02),
                blurRadius: 30,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: widget.child,
        ),
      ),
    );
  }
}
// ============================================================
// STAGGERED FADE-IN WIDGET (for list items)
// ============================================================
class FadeSlideIn extends StatefulWidget {
  final Widget child;
  final int delayMs;
  final Offset offset;
  const FadeSlideIn({
    Key? key,
    required this.child,
    this.delayMs = 0,
    this.offset = const Offset(0, 20),
  }) : super(key: key);
  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}
class _FadeSlideInState extends State<FadeSlideIn>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: widget.offset,
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    Future.delayed(Duration(milliseconds: widget.delayMs), () {
      if (mounted) _controller.forward();
    });
  }
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Opacity(
          opacity: _fadeAnim.value,
          child: Transform.translate(
            offset: _slideAnim.value,
            child: child,
          ),
        );
      },
      child: widget.child,
    );
  }
}
// ============================================================
// HOME PAGE — with staggered animations
// ============================================================
class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final displayName = user?.displayName ?? 'Пользователь';
    final hour = DateTime.now().hour;
    final greeting = hour < 12
        ? 'Доброе утро'
        : hour < 18
            ? 'Добрый день'
            : 'Добрый вечер';
    return SafeArea(
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            FadeSlideIn(
              delayMs: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'PULSECHECK',
                          style: TextStyle(
                            fontSize: 10,
                            letterSpacing: 3,
                            color: AppColors.mint.withOpacity(0.7),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '$greeting, $displayName! 👋',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textDark,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  _NotificationButton(),
                ],
              ),
            ),
            const SizedBox(height: 24),
            FadeSlideIn(delayMs: 100, child: _buildStatusCard()),
            const SizedBox(height: 20),
            FadeSlideIn(
              delayMs: 200,
              child: Text(
                'Быстрые действия',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textDark.withOpacity(0.9),
                ),
              ),
            ),
            const SizedBox(height: 12),
            _buildQuickActions(context),
            const SizedBox(height: 20),
            FadeSlideIn(
              delayMs: 500,
              child: Text(
                'Напоминания',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textDark.withOpacity(0.9),
                ),
              ),
            ),
            const SizedBox(height: 12),
            FadeSlideIn(delayMs: 550, child: _buildMedicineReminder(context)),
            const SizedBox(height: 20),
            FadeSlideIn(delayMs: 600, child: _buildSOSButton(context)),
            const SizedBox(height: 100),
          ],
        ),
      ),
    );
  }
  Widget _buildStatusCard() {
    return StreamBuilder<QuerySnapshot>(
      stream: DatabaseService().getPulseHistory(),
      builder: (context, snapshot) {
        int lastPulse = 72;
        if (snapshot.hasData && snapshot.data!.docs.isNotEmpty) {
          final data = snapshot.data!.docs.first.data() as Map<String, dynamic>?;
          lastPulse = (data?['bpm'] as num?)?.toInt() ?? 72;
        }
        return _StatusCardContent(lastPulse: lastPulse);
      },
    );
  }
  Widget _buildQuickActions(BuildContext context) {
    final actions = [
      ['Пульс', Icons.favorite_rounded, AppColors.coral, const Color(0xFFFF8A8A)],
      ['Дыхание', Icons.air_rounded, AppColors.sky, const Color(0xFF7DD3FC)],
      ['Лекарства', Icons.medication_rounded, AppColors.mint, AppColors.mintLight],
      ['Первая помощь', Icons.health_and_safety_rounded, AppColors.orange, const Color(0xFFFFBF5A)],
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.4,
      ),
      itemCount: actions.length,
      itemBuilder: (context, index) {
        return FadeSlideIn(
          delayMs: 300 + index * 80,
          child: SoftCard(
            onTap: () {
              Widget page;
              switch (index) {
                case 0:
                  _openPulseScanner(context);
                  return;
                case 1:
                  page = const BreathingPage();
                  break;
                case 2:
                  page = const MedicinePage();
                  break;
                case 3:
                  page = const FirstAidPage();
                  break;
                default:
                  return;
              }
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => page),
              );
            },
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    gradient: LinearGradient(
                      colors: [
                        actions[index][2] as Color,
                        actions[index][3] as Color,
                      ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: (actions[index][2] as Color).withOpacity(0.25),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Icon(
                    actions[index][1] as IconData,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
                Text(
                  actions[index][0] as String,
                  style: const TextStyle(
                    color: AppColors.textDark,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
  Widget _buildMedicineReminder(BuildContext context) {
    return SoftCard(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const MedicinePage()),
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: AppColors.mintSoft,
            ),
            child: const Icon(Icons.medication_rounded, color: AppColors.mint, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Напоминания о лекарствах',
                  style: TextStyle(
                    color: AppColors.textDark,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Проверьте расписание приема',
                  style: TextStyle(color: AppColors.textLight, fontSize: 12),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textHint, size: 20),
        ],
      ),
    );
  }
  void _openPulseScanner(BuildContext context) async {
    try {
      final cameras = await availableCameras();
      if (cameras.isNotEmpty && context.mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => PulseScannerPage(camera: cameras.first),
          ),
        );
      } else if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Камера не найдена'),
            backgroundColor: AppColors.coral,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            margin: const EdgeInsets.all(16),
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ошибка камеры: $e'),
            backgroundColor: AppColors.coral,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            margin: const EdgeInsets.all(16),
          ),
        );
      }
    }
  }
  Widget _buildSOSButton(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const SOSPage()),
      ),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: const LinearGradient(
            colors: [Color(0xFFFF6B6B), Color(0xFFFF8E53)],
          ),
          boxShadow: [
            BoxShadow(
              color: AppColors.coral.withOpacity(0.3),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.2),
              ),
              child: const Icon(Icons.warning_rounded, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 16),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'SOS СИГНАЛ',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1,
                    ),
                  ),
                  SizedBox(height: 2),
                  Text(
                    'Экстренный вызов помощи',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white70, size: 16),
          ],
        ),
      ),
    );
  }
}
// ============================================================
// NOTIFICATION BUTTON — with animated glow
// ============================================================
class _NotificationButton extends StatefulWidget {
  @override
  State<_NotificationButton> createState() => _NotificationButtonState();
}
class _NotificationButtonState extends State<_NotificationButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _glowController;
  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }
  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, _) {
        return Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [AppColors.mint, AppColors.sky],
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.mint.withOpacity(0.2 + 0.15 * _glowController.value),
                blurRadius: 12 + 6 * _glowController.value,
              ),
            ],
          ),
          child: const Icon(Icons.notifications_rounded, size: 20, color: Colors.white),
        );
      },
    );
  }
}
// ============================================================
// STATUS CARD — animated shimmer on gradient
// ============================================================
class _StatusCardContent extends StatefulWidget {
  final int lastPulse;
  const _StatusCardContent({required this.lastPulse});
  @override
  State<_StatusCardContent> createState() => _StatusCardContentState();
}
class _StatusCardContentState extends State<_StatusCardContent>
    with SingleTickerProviderStateMixin {
  late AnimationController _shimmerController;
  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
  }
  @override
  void dispose() {
    _shimmerController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (context, child) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: const [AppColors.mint, AppColors.sky],
              stops: [
                0.0,
                0.5 + 0.5 * math.sin(_shimmerController.value * 2 * math.pi),
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.mint.withOpacity(0.3),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: child,
        );
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.5),
                      blurRadius: 8,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'Состояние здоровья',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(child: _healthMetric('❤️', 'Пульс', '${widget.lastPulse}', 'bpm')),
              Expanded(child: _healthMetric('🫁', 'Дыхание', '16', '/мин')),
              Expanded(child: _healthMetric('🌡️', 'Темп.', '36.6', '°C')),
              Expanded(child: _healthMetric('💧', 'SpO2', '98', '%')),
            ],
          ),
        ],
      ),
    );
  }
  Widget _healthMetric(String emoji, String label, String value, String unit) {
    return Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 24)),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.7),
            fontSize: 10,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 4),
        Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: Text(
                unit,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.6),
                  fontSize: 9,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
// ============================================================
// PULSE SCANNER PAGE — pulse math 100% PRESERVED
// ============================================================
class PulseScannerPage extends StatefulWidget {
  final CameraDescription camera;
  const PulseScannerPage({Key? key, required this.camera}) : super(key: key);
  @override
  State<PulseScannerPage> createState() => _PulseScannerPageState();
}
class _PulseScannerPageState extends State<PulseScannerPage>
    with TickerProviderStateMixin {
  late CameraController _cameraController;
  late AnimationController _pulseController;
  late AnimationController _ringController;
  late AnimationController _bpmCountController;
  late Animation<double> _pulseAnim;
  late Animation<double> _ringAnim;
  Timer? _uiUpdateTimer;
  Timer? _scanDurationTimer;
  bool _isScanning = false;
  bool _cameraReady = false;
  bool _cameraDisposed = false;
  int _secondsElapsed = 0;
  // ── PULSE MATH — UNTOUCHED ──
  final List<double> _brightnessHistory = [];
  final List<int> _bpmBuffer = [];
  final List<int> _allSessionBpms = [];
  double _stableBpm = 0.0;
  int _displayBpm = 0;
  int _minBpm = 0;
  int _maxBpm = 0;
  int _avgBpm = 0;
  final List<int> _bpmGraphHistory = [];
  final _dbService = DatabaseService();
  bool _fingerDetected = false;
  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
    _pulseAnim = CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOutSine,
    );
    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat();
    _ringAnim = CurvedAnimation(
      parent: _ringController,
      curve: Curves.easeOut,
    );
    _bpmCountController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _cameraController = CameraController(
      widget.camera,
      ResolutionPreset.low,
      enableAudio: false,
    );
    _cameraController.initialize().then((_) {
      if (mounted && !_cameraDisposed) {
        setState(() => _cameraReady = true);
      }
    }).catchError((e) {
      debugPrint('Camera init error: $e');
    });
  }
  void _startScan() {
    if (!_cameraReady || _cameraDisposed) return;
    setState(() {
      _isScanning = true;
      _secondsElapsed = 0;
      _brightnessHistory.clear();
      _bpmBuffer.clear();
      _allSessionBpms.clear();
      _bpmGraphHistory.clear();
      _stableBpm = 0;
      _displayBpm = 0;
      _minBpm = 0;
      _maxBpm = 0;
      _avgBpm = 0;
      _fingerDetected = false;
    });
    _cameraController.setFlashMode(FlashMode.torch).catchError((_) {});
    _cameraController.startImageStream((CameraImage image) {
      if (_isScanning && mounted) _processFrame(image);
    }).catchError((e) {
      debugPrint('Image stream error: $e');
    });
    _scanDurationTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        _secondsElapsed++;
        if (_secondsElapsed >= 45) _stopScan();
      });
    });
    _uiUpdateTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_bpmBuffer.isNotEmpty) {
        _bpmBuffer.sort();
        List<int> cleanBuffer = _bpmBuffer;
        if (_bpmBuffer.length >= 4) {
          int start = (_bpmBuffer.length * 0.2).toInt();
          int end = (_bpmBuffer.length * 0.8).toInt();
          cleanBuffer = _bpmBuffer.sublist(start, end);
        }
        if (cleanBuffer.isEmpty) return;
        double newRawAvg =
            cleanBuffer.reduce((a, b) => a + b) / cleanBuffer.length;
        if (_stableBpm == 0) {
          _stableBpm = newRawAvg;
        } else {
          double factor =
              ((newRawAvg - _stableBpm).abs() > 12) ? 0.2 : 0.6;
          _stableBpm = (_stableBpm * (1 - factor)) + (newRawAvg * factor);
        }
        int finalBpm = _stableBpm.toInt();
        if (finalBpm > 40) {
          _allSessionBpms.add(finalBpm);
          _bpmCountController.forward(from: 0);
          setState(() {
            _displayBpm = finalBpm;
            _bpmGraphHistory.add(finalBpm);
            _minBpm =
                (_minBpm == 0) ? finalBpm : math.min(_minBpm, finalBpm);
            _maxBpm = math.max(_maxBpm, finalBpm);
            _avgBpm = (_allSessionBpms.reduce((a, b) => a + b) /
                    _allSessionBpms.length)
                .round();
          });
        }
        _bpmBuffer.clear();
      }
    });
  }
  void _stopScan() async {
    _uiUpdateTimer?.cancel();
    _uiUpdateTimer = null;
    _scanDurationTimer?.cancel();
    _scanDurationTimer = null;
    if (_isScanning && !_cameraDisposed) {
      try {
        await _cameraController.stopImageStream();
      } catch (e) {
        debugPrint('Error stopping image stream: $e');
      }
      try {
        await _cameraController.setFlashMode(FlashMode.off);
      } catch (e) {
        debugPrint('Error turning off flash: $e');
      }
      if (mounted) {
        setState(() => _isScanning = false);
        if (_avgBpm > 0) {
          _showResults();
        }
      }
    }
  }
  // ── PULSE PROCESSING — 100% ORIGINAL MATH ──
  void _processFrame(CameraImage image) {
    int sum = 0;
    final bytes = image.planes[0].bytes;
    for (int i = 0; i < bytes.length; i += 4) {
      sum += bytes[i];
    }
    double avg = sum / (bytes.length / 4);
    if (mounted) {
      setState(() {
        _fingerDetected = avg > 100;
      });
    }
    _brightnessHistory.add(avg);
    if (_brightnessHistory.length > 150) _brightnessHistory.removeAt(0);
    if (_brightnessHistory.length >= 100 &&
        _brightnessHistory.length % 5 == 0) {
      int? calculated = _calculateInstantBPM();
      if (calculated != null && calculated > 45 && calculated < 160) {
        _bpmBuffer.add(calculated);
      }
    }
  }
  // ── BPM CALCULATION — 100% ORIGINAL ──
  int? _calculateInstantBPM() {
    List<int> peaks = [];
    List<double> sorted = List.from(_brightnessHistory)..sort();
    double threshold = sorted[sorted.length ~/ 2];
    for (int i = 2; i < _brightnessHistory.length - 2; i++) {
      if (_brightnessHistory[i] > threshold &&
          _brightnessHistory[i] > _brightnessHistory[i - 1] &&
          _brightnessHistory[i] > _brightnessHistory[i + 1]) {
        peaks.add(i);
      }
    }
    if (peaks.length < 2) return null;
    double totalInterval = 0;
    int count = 0;
    for (int i = 1; i < peaks.length; i++) {
      int interval = peaks[i] - peaks[i - 1];
      if (interval > 10 && interval < 50) {
        totalInterval += interval;
        count++;
      }
    }
    return count == 0 ? null : (1800 / (totalInterval / count)).toInt();
  }
  void _showResults() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      isDismissible: false,
      transitionAnimationController: AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 400),
      ),
      builder: (context) => _ResultsSheet(
        avgBpm: _avgBpm,
        minBpm: _minBpm,
        maxBpm: _maxBpm,
        secondsElapsed: _secondsElapsed,
        measurementCount: _allSessionBpms.length,
        dbService: _dbService,
      ),
    );
  }
  String _getPulseHint() {
    if (!_isScanning) return 'Приложите палец к камере телефона';
    if (!_fingerDetected) return 'Прижмите палец плотнее к камере';
    if (_displayBpm == 0) return 'Анализируем сигнал...';
    return 'Не убирайте палец до конца теста';
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            // Top bar
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      if (_isScanning) _stopScan();
                      Navigator.pop(context);
                    },
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: const Icon(
                        Icons.arrow_back_ios_new_rounded,
                        size: 16,
                        color: AppColors.textMedium,
                      ),
                    ),
                  ),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: _isScanning
                          ? AppColors.coral.withOpacity(0.08)
                          : AppColors.bg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _isScanning
                            ? AppColors.coral.withOpacity(0.15)
                            : AppColors.border,
                      ),
                    ),
                    child: Row(
                      children: [
                        if (_isScanning)
                          _PulsingDot(color: AppColors.coral),
                        if (_isScanning) const SizedBox(width: 8),
                        Text(
                          _isScanning
                              ? 'АНАЛИЗ: ${_secondsElapsed}s'
                              : 'ГОТОВ К СКАНУ',
                          style: TextStyle(
                            color: _isScanning ? AppColors.coral : AppColors.textLight,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Finger detection indicator with smooth transition
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              transitionBuilder: (child, animation) {
                return SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, -0.5),
                    end: Offset.zero,
                  ).animate(CurvedAnimation(
                    parent: animation,
                    curve: Curves.easeOutCubic,
                  )),
                  child: FadeTransition(opacity: animation, child: child),
                );
              },
              child: _isScanning
                  ? Container(
                      key: ValueKey(_fingerDetected),
                      margin: const EdgeInsets.symmetric(horizontal: 40),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _fingerDetected
                            ? AppColors.mintSoft
                            : AppColors.orange.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _fingerDetected
                              ? AppColors.mint.withOpacity(0.3)
                              : AppColors.orange.withOpacity(0.2),
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _fingerDetected
                                ? Icons.check_circle_rounded
                                : Icons.touch_app_rounded,
                            color: _fingerDetected ? AppColors.mint : AppColors.orange,
                            size: 20,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              _fingerDetected
                                  ? 'Палец обнаружен! Идёт измерение...'
                                  : 'Прижмите палец к камере и вспышке',
                              style: TextStyle(
                                color: (_fingerDetected
                                        ? AppColors.mint
                                        : AppColors.orange)
                                    .withOpacity(0.8),
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : const SizedBox.shrink(),
            ),
            // Camera + BPM
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 220,
                    height: 220,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Outer expanding ring
                        if (_isScanning)
                          AnimatedBuilder(
                            animation: _ringAnim,
                            builder: (c, _) => Container(
                              width: 220 * (0.8 + 0.2 * _ringAnim.value),
                              height: 220 * (0.8 + 0.2 * _ringAnim.value),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: AppColors.mint
                                      .withOpacity(0.3 * (1 - _ringAnim.value)),
                                  width: 2,
                                ),
                              ),
                            ),
                          ),
                        // Inner pulse ring
                        if (_isScanning && _fingerDetected)
                          AnimatedBuilder(
                            animation: _pulseAnim,
                            builder: (c, _) => Container(
                              width: 200 * (0.93 + 0.07 * _pulseAnim.value),
                              height: 200 * (0.93 + 0.07 * _pulseAnim.value),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: AppColors.sky
                                      .withOpacity(0.3 * _pulseAnim.value),
                                  width: 1.5,
                                ),
                              ),
                            ),
                          ),
                        // Camera preview circle
                        RepaintBoundary(
                          child: ClipOval(
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 400),
                              width: 160,
                              height: 160,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: _fingerDetected
                                      ? AppColors.mint.withOpacity(0.5)
                                      : AppColors.border,
                                  width: 3,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: _fingerDetected
                                        ? AppColors.mint.withOpacity(0.15)
                                        : AppColors.mint.withOpacity(0.05),
                                    blurRadius: _fingerDetected ? 30 : 15,
                                  ),
                                ],
                              ),
                              child: ClipOval(
                                child: _cameraReady
                                    ? CameraPreview(_cameraController)
                                    : Container(
                                        color: AppColors.bg,
                                        child: const Center(
                                          child: CircularProgressIndicator(
                                            color: AppColors.mint,
                                            strokeWidth: 2,
                                          ),
                                        ),
                                      ),
                              ),
                            ),
                          ),
                        ),
                        // Overlay when not scanning
                        if (!_isScanning)
                          AnimatedOpacity(
                            opacity: 1.0,
                            duration: const Duration(milliseconds: 300),
                            child: Container(
                              width: 160,
                              height: 160,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withOpacity(0.85),
                              ),
                              child: const Icon(
                                Icons.favorite_rounded,
                                color: AppColors.coral,
                                size: 56,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),
                  // BPM display with counter animation
                  AnimatedBuilder(
                    animation: _bpmCountController,
                    builder: (context, child) {
                      return Transform.scale(
                        scale: 1.0 +
                            0.05 *
                                Curves.elasticOut
                                    .transform(_bpmCountController.value),
                        child: child,
                      );
                    },
                    child: Text(
                      _displayBpm > 0 ? '$_displayBpm' : '--',
                      style: const TextStyle(
                        fontSize: 80,
                        fontWeight: FontWeight.w900,
                        color: AppColors.textDark,
                      ),
                    ),
                  ),
                  Text(
                    'BPM',
                    style: TextStyle(
                      fontSize: 12,
                      letterSpacing: 4,
                      color: AppColors.textHint,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  // Pulse graph
                  if (_isScanning && _bpmGraphHistory.length >= 2) ...[
                    const SizedBox(height: 32),
                    RepaintBoundary(
                      child: SizedBox(
                        height: 60,
                        width: 260,
                        child: CustomPaint(
                          painter: _PulseGraphPainter(_bpmGraphHistory),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            // Stats
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: _displayBpm > 0
                  ? Padding(
                      key: const ValueKey('stats'),
                      padding: const EdgeInsets.symmetric(horizontal: 40),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _statChip('MIN', _minBpm, AppColors.sky),
                          _statChip('AVG', _avgBpm, AppColors.mint),
                          _statChip('MAX', _maxBpm, AppColors.orange),
                        ],
                      ),
                    )
                  : const SizedBox.shrink(),
            ),
            const SizedBox(height: 20),
            // Start/Stop button
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: SizedBox(
                width: double.infinity,
                height: 60,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  child: ElevatedButton(
                    onPressed: _isScanning ? _stopScan : _startScan,
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          _isScanning ? AppColors.bg : AppColors.coral,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      elevation: _isScanning ? 0 : 6,
                      shadowColor: AppColors.coral.withOpacity(0.3),
                      side: _isScanning
                          ? BorderSide(color: AppColors.border)
                          : BorderSide.none,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 200),
                          child: Icon(
                            _isScanning
                                ? Icons.stop_rounded
                                : Icons.play_arrow_rounded,
                            key: ValueKey(_isScanning),
                            color: _isScanning
                                ? AppColors.textMedium
                                : Colors.white,
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _isScanning ? 'ЗАВЕРШИТЬ ТЕСТ' : 'НАЧАТЬ СКАН',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2,
                            fontSize: 14,
                            color: _isScanning
                                ? AppColors.textMedium
                                : Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: Text(
                _getPulseHint(),
                key: ValueKey(_getPulseHint()),
                style: TextStyle(color: AppColors.textLight, fontSize: 12),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
  Widget _statChip(String label, int value, Color color) {
    return SoftCard(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        children: [
          Text(
            label,
            style: TextStyle(
              color: AppColors.textLight,
              fontSize: 9,
              fontWeight: FontWeight.w600,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            '$value',
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
  @override
  void dispose() {
    _cameraDisposed = true;
    _uiUpdateTimer?.cancel();
    _scanDurationTimer?.cancel();
    if (_isScanning) {
      _cameraController.stopImageStream().catchError((_) {});
      _cameraController.setFlashMode(FlashMode.off).catchError((_) {});
    }
    _cameraController.dispose();
    _pulseController.dispose();
    _ringController.dispose();
    _bpmCountController.dispose();
    super.dispose();
  }
}
// ============================================================
// PULSING DOT WIDGET
// ============================================================
class _PulsingDot extends StatefulWidget {
  final Color color;
  const _PulsingDot({required this.color});
  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}
class _PulsingDotState extends State<_PulsingDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
  }
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Container(
          width: 6,
          height: 6,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color,
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.5 * _controller.value),
                blurRadius: 6,
              ),
            ],
          ),
        );
      },
    );
  }
}
// ============================================================
// RESULTS BOTTOM SHEET — extracted widget
// ============================================================
class _ResultsSheet extends StatelessWidget {
  final int avgBpm;
  final int minBpm;
  final int maxBpm;
  final int secondsElapsed;
  final int measurementCount;
  final DatabaseService dbService;
  const _ResultsSheet({
    required this.avgBpm,
    required this.minBpm,
    required this.maxBpm,
    required this.secondsElapsed,
    required this.measurementCount,
    required this.dbService,
  });
  String _getPulseStatus(int bpm) {
    if (bpm < 60) return '🔵 Пониженный пульс (брадикардия)';
    if (bpm <= 100) return '🟢 Нормальный пульс';
    return '🔴 Повышенный пульс (тахикардия)';
  }
  Color _getPulseStatusColor(int bpm) {
    if (bpm < 60) return AppColors.sky;
    if (bpm <= 100) return AppColors.mint;
    return AppColors.coral;
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        boxShadow: [
          BoxShadow(
            color: AppColors.textDark.withOpacity(0.1),
            blurRadius: 30,
            offset: const Offset(0, -10),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'РЕЗУЛЬТАТЫ АНАЛИЗА',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
              color: AppColors.textLight,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            _getPulseStatus(avgBpm),
            style: TextStyle(
              fontSize: 12,
              color: _getPulseStatusColor(avgBpm),
            ),
          ),
          const SizedBox(height: 16),
          TweenAnimationBuilder<int>(
            tween: IntTween(begin: 0, end: avgBpm),
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeOutCubic,
            builder: (context, value, _) {
              return Text(
                '$value',
                style: const TextStyle(
                  fontSize: 72,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textDark,
                ),
              );
            },
          ),
          Text(
            'BPM (среднее)',
            style: TextStyle(
              color: AppColors.textLight,
              fontSize: 12,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _resultStat('MIN', minBpm, AppColors.sky),
              _resultStat('AVG', avgBpm, AppColors.mint),
              _resultStat('MAX', maxBpm, AppColors.orange),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.bg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.timer_outlined, color: AppColors.textLight, size: 16),
                const SizedBox(width: 8),
                Text(
                  'Длительность: ${secondsElapsed}с · Замеров: $measurementCount',
                  style: TextStyle(color: AppColors.textLight, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: () async {
                await dbService.savePulseData(avgBpm, minBpm, maxBpm);
                if (context.mounted) {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: const Text('✅ Результаты сохранены!'),
                    backgroundColor: AppColors.mint,
                    behavior: SnackBarBehavior.floating,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    margin: const EdgeInsets.all(16),
                  ));
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.mint,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
              ),
              child: const Text(
                'СОХРАНИТЬ В ПРОФИЛЬ',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.5,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text(
              'Не сохранять',
              style: TextStyle(color: AppColors.textLight),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
  Widget _resultStat(String label, int value, Color color) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            color: AppColors.textLight,
            fontSize: 10,
            fontWeight: FontWeight.w600,
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 6),
        TweenAnimationBuilder<int>(
          tween: IntTween(begin: 0, end: value),
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeOutCubic,
          builder: (context, v, _) {
            return Text(
              '$v',
              style: TextStyle(
                color: color,
                fontSize: 28,
                fontWeight: FontWeight.w800,
              ),
            );
          },
        ),
        Text(
          'BPM',
          style: TextStyle(color: AppColors.textHint, fontSize: 10),
        ),
      ],
    );
  }
}
// ============================================================
// PULSE GRAPH PAINTER — smoothed with bezier curves
// ============================================================
class _PulseGraphPainter extends CustomPainter {
  final List<int> data;
  _PulseGraphPainter(this.data);
  @override
  void paint(Canvas canvas, Size size) {
    if (data.length < 2) return;
    final paint = Paint()
      ..color = AppColors.mint
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final path = Path();
    final stepX = size.width / (data.length - 1);
    // Find min/max for proper scaling
    int minVal = data.reduce(math.min);
    int maxVal = data.reduce(math.max);
    double range = (maxVal - minVal).toDouble();
    if (range < 10) range = 10;
    List<Offset> points = [];
    for (int i = 0; i < data.length; i++) {
      double x = i * stepX;
      double normalized = (data[i] - minVal) / range;
      double y = size.height - (normalized * size.height * 0.8 + size.height * 0.1);
      points.add(Offset(x, y));
    }
    // Smooth bezier path
    path.moveTo(points[0].dx, points[0].dy);
    for (int i = 1; i < points.length; i++) {
      double cpx1 = points[i - 1].dx + (points[i].dx - points[i - 1].dx) / 3;
      double cpx2 = points[i].dx - (points[i].dx - points[i - 1].dx) / 3;
      path.cubicTo(cpx1, points[i - 1].dy, cpx2, points[i].dy, points[i].dx, points[i].dy);
    }
    canvas.drawPath(path, paint);
    // Gradient fill under the curve
    final fillPath = Path.from(path)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    final fillPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          AppColors.mint.withOpacity(0.25),
          AppColors.mint.withOpacity(0.0),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawPath(fillPath, fillPaint);
    // Draw last point dot with glow
    if (points.isNotEmpty) {
      final lastPoint = points.last;
      canvas.drawCircle(
        lastPoint,
        6,
        Paint()..color = AppColors.mint.withOpacity(0.2),
      );
      canvas.drawCircle(
        lastPoint,
        3,
        Paint()..color = AppColors.mint,
      );
    }
  }
  @override
  bool shouldRepaint(covariant _PulseGraphPainter old) =>
      old.data.length != data.length ||
      (data.isNotEmpty && old.data.isNotEmpty && old.data.last != data.last);
}
// ============================================================
// BREATHING PAGE — smoother circle animation
// ============================================================
class BreathingPage extends StatefulWidget {
  const BreathingPage({Key? key}) : super(key: key);
  @override
  State<BreathingPage> createState() => _BreathingPageState();
}
class _BreathingPageState extends State<BreathingPage>
    with TickerProviderStateMixin {
  bool _isActive = false;
  int _phase = 0;
  int _phaseSeconds = 0;
  int _breathCount = 0;
  int _totalSeconds = 0;
  Timer? _timer;
  late AnimationController _scaleController;
  late AnimationController _glowController;
  final _dbService = DatabaseService();
  final List<Map<String, dynamic>> _phases = [
    {'label': 'ВДОХ', 'duration': 4, 'color': AppColors.sky},
    {'label': 'ЗАДЕРЖКА', 'duration': 4, 'color': AppColors.mint},
    {'label': 'ВЫДОХ', 'duration': 6, 'color': AppColors.purple},
  ];
  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }
  void _start() {
    setState(() {
      _isActive = true;
      _phase = 0;
      _phaseSeconds = 0;
      _breathCount = 0;
      _totalSeconds = 0;
    });
    _startPhaseAnimation();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        _phaseSeconds++;
        _totalSeconds++;
        if (_phaseSeconds >= (_phases[_phase]['duration'] as int)) {
          _phaseSeconds = 0;
          _phase = (_phase + 1) % 3;
          if (_phase == 0) _breathCount++;
          _startPhaseAnimation();
        }
      });
    });
  }
  void _startPhaseAnimation() {
    _scaleController.duration =
        Duration(seconds: _phases[_phase]['duration'] as int);
    if (_phase == 0) {
      _scaleController.forward(from: 0);
    } else if (_phase == 2) {
      _scaleController.reverse(from: 1);
    } else {
      // Hold — keep current value
      _scaleController.stop();
    }
  }
  void _stop() {
    _timer?.cancel();
    _scaleController.stop();
    _scaleController.reset();
    if (_breathCount > 0 && _totalSeconds > 0) {
      int rate = (_breathCount / math.max(_totalSeconds, 1) * 60).round();
      _dbService.saveBreathingData(
        rate > 0 ? rate : 16,
        _breathCount,
        _totalSeconds,
      );
    }
    setState(() {
      _isActive = false;
      _phase = 0;
      _phaseSeconds = 0;
    });
  }
  @override
  Widget build(BuildContext context) {
    Color currentColor = _phases[_phase]['color'] as Color;
    String currentLabel = _isActive ? (_phases[_phase]['label'] as String) : 'ГОТОВ';
    int remaining =
        _isActive ? ((_phases[_phase]['duration'] as int) - _phaseSeconds) : 0;
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildPageHeader(context, 'Дыхательная гимнастика'),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedDefaultTextStyle(
                    duration: const Duration(milliseconds: 400),
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: currentColor,
                      letterSpacing: 4,
                    ),
                    child: Text(currentLabel),
                  ),
                  const SizedBox(height: 40),
                  AnimatedBuilder(
                    animation: Listenable.merge([_scaleController, _glowController]),
                    builder: (c, _) {
                      double scale =
                          _isActive ? 0.6 + 0.4 * _scaleController.value : 0.6;
                      return Stack(
                        alignment: Alignment.center,
                        children: [
                          // Outer glow ring
                          Container(
                            width: 260 * scale,
                            height: 260 * scale,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: currentColor.withOpacity(
                                    0.1 + 0.05 * _glowController.value),
                                width: 1,
                              ),
                            ),
                          ),
                          Container(
                            width: 240 * scale,
                            height: 240 * scale,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: currentColor.withOpacity(0.15),
                                width: 1.5,
                              ),
                            ),
                          ),
                          Container(
                            width: 180 * scale,
                            height: 180 * scale,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  currentColor.withOpacity(0.15),
                                  currentColor.withOpacity(0.03),
                                ],
                              ),
                              border: Border.all(
                                color: currentColor.withOpacity(0.4),
                                width: 2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: currentColor.withOpacity(
                                      0.1 + 0.1 * _glowController.value),
                                  blurRadius: 30 + 10 * _glowController.value,
                                ),
                              ],
                            ),
                            child: Center(
                              child: AnimatedSwitcher(
                                duration: const Duration(milliseconds: 200),
                                child: Text(
                                  _isActive ? '$remaining' : '🫁',
                                  key: ValueKey(_isActive ? remaining : 'icon'),
                                  style: TextStyle(
                                    fontSize: _isActive ? 48 : 56,
                                    fontWeight: FontWeight.w900,
                                    color: AppColors.textDark,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 40),
                  // Phase indicator dots
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(3, (i) {
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: _phase == i ? 24 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: _phase == i
                              ? (_phases[i]['color'] as Color)
                              : AppColors.border,
                        ),
                      );
                    }),
                  ),
                  if (_isActive) ...[
                    const SizedBox(height: 20),
                    Text(
                      'Циклов: $_breathCount',
                      style: TextStyle(color: AppColors.textLight, fontSize: 14),
                    ),
                  ],
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: SizedBox(
                width: double.infinity,
                height: 60,
                child: ElevatedButton(
                  onPressed: _isActive ? _stop : _start,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isActive ? AppColors.bg : AppColors.sky,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                    elevation: _isActive ? 0 : 4,
                    side: _isActive
                        ? BorderSide(color: AppColors.border)
                        : BorderSide.none,
                  ),
                  child: Text(
                    _isActive ? 'ОСТАНОВИТЬ' : 'НАЧАТЬ',
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2,
                      color: _isActive ? AppColors.textMedium : Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
  @override
  void dispose() {
    _timer?.cancel();
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }
}
// ============================================================
// MEDICINE PAGE — with slide-in animations & haptic feedback
// ============================================================
class MedicinePage extends StatefulWidget {
  const MedicinePage({Key? key}) : super(key: key);
  @override
  State<MedicinePage> createState() => _MedicinePageState();
}
class _MedicinePageState extends State<MedicinePage> {
  final List<Map<String, dynamic>> _medicines = [
    {'name': 'Витамин D', 'dose': '1000 МЕ', 'time': '08:00', 'taken': false},
    {'name': 'Омега-3', 'dose': '500мг', 'time': '12:00', 'taken': false},
    {'name': 'Магний B6', 'dose': '2 таблетки', 'time': '21:00', 'taken': false},
  ];
  @override
  Widget build(BuildContext context) {
    int taken = _medicines.where((m) => m['taken'] == true).length;
    double progress = _medicines.isNotEmpty ? taken / _medicines.length : 0;
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  _backButton(context),
                  const SizedBox(width: 16),
                  const Text(
                    'Мои лекарства',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textDark,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: _showAddDialog,
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: AppColors.mintSoft,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.add_rounded, size: 20, color: AppColors.mint),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SoftCard(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    SizedBox(
                      width: 60,
                      height: 60,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          SizedBox(
                            width: 60,
                            height: 60,
                            child: TweenAnimationBuilder<double>(
                              tween: Tween(begin: 0, end: progress),
                              duration: const Duration(milliseconds: 600),
                              curve: Curves.easeOutCubic,
                              builder: (context, value, _) {
                                return CircularProgressIndicator(
                                  value: value,
                                  strokeWidth: 5,
                                  backgroundColor: AppColors.border,
                                  valueColor: const AlwaysStoppedAnimation(AppColors.mint),
                                  strokeCap: StrokeCap.round,
                                );
                              },
                            ),
                          ),
                          Text(
                            '${(progress * 100).round()}%',
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              color: AppColors.mint,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 20),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Прогресс на сегодня',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textDark,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '$taken из ${_medicines.length} приемов',
                          style: TextStyle(fontSize: 12, color: AppColors.textLight),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: _medicines.length,
                itemBuilder: (context, index) {
                  final med = _medicines[index];
                  return FadeSlideIn(
                    delayMs: index * 100,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Dismissible(
                        key: UniqueKey(),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          decoration: BoxDecoration(
                            color: AppColors.coral.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Icon(Icons.delete_rounded, color: AppColors.coral),
                        ),
                        onDismissed: (_) => setState(() => _medicines.removeAt(index)),
                        child: SoftCard(
                          onTap: () {
                            HapticFeedback.lightImpact();
                            setState(() => med['taken'] = !(med['taken'] as bool));
                          },
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              AnimatedContainer(
                                duration: const Duration(milliseconds: 300),
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(14),
                                  color: (med['taken'] as bool)
                                      ? AppColors.mintSoft
                                      : AppColors.skyLight,
                                ),
                                child: AnimatedSwitcher(
                                  duration: const Duration(milliseconds: 300),
                                  child: Icon(
                                    (med['taken'] as bool)
                                        ? Icons.check_rounded
                                        : Icons.medication_rounded,
                                    key: ValueKey(med['taken']),
                                    color: (med['taken'] as bool)
                                        ? AppColors.mint
                                        : AppColors.sky,
                                    size: 22,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    AnimatedDefaultTextStyle(
                                      duration: const Duration(milliseconds: 300),
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        decoration: (med['taken'] as bool)
                                            ? TextDecoration.lineThrough
                                            : null,
                                        color: (med['taken'] as bool)
                                            ? AppColors.textLight
                                            : AppColors.textDark,
                                      ),
                                      child: Text('${med['name']} ${med['dose']}'),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${med['time']}',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: AppColors.textHint,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
  void _showAddDialog() {
    final nameCtrl = TextEditingController();
    final doseCtrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        padding: EdgeInsets.only(
          top: 24,
          left: 24,
          right: 24,
          bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        ),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Добавить лекарство',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppColors.textDark,
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: nameCtrl,
              style: const TextStyle(color: AppColors.textDark),
              decoration: InputDecoration(
                hintText: 'Название',
                hintStyle: TextStyle(color: AppColors.textHint),
                filled: true,
                fillColor: AppColors.bg,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: AppColors.mint, width: 2),
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: doseCtrl,
              style: const TextStyle(color: AppColors.textDark),
              decoration: InputDecoration(
                hintText: 'Дозировка',
                hintStyle: TextStyle(color: AppColors.textHint),
                filled: true,
                fillColor: AppColors.bg,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: AppColors.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: AppColors.mint, width: 2),
                ),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: () {
                  if (nameCtrl.text.isNotEmpty) {
                    setState(() => _medicines.add({
                          'name': nameCtrl.text,
                          'dose': doseCtrl.text,
                          'time': '08:00',
                          'taken': false,
                        }));
                    Navigator.pop(context);
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.mint,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: const Text(
                  'ДОБАВИТЬ',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
// ============================================================
// FIRST AID PAGE — with smooth expand animation
// ============================================================
class FirstAidPage extends StatefulWidget {
  const FirstAidPage({Key? key}) : super(key: key);
  @override
  State<FirstAidPage> createState() => _FirstAidPageState();
}
class _FirstAidPageState extends State<FirstAidPage> {
  int _expandedIndex = -1;
  final List<Map<String, dynamic>> _guides = [
    {
      'title': 'Остановка сердца',
      'icon': Icons.favorite_rounded,
      'color': AppColors.coral,
      'steps': [
        'Проверьте сознание',
        'Вызовите скорую (103)',
        'Положите на твёрдую поверхность',
        '30 нажатий на грудину',
        '2 вдоха, цикл 30:2',
      ],
    },
    {
      'title': 'Кровотечение',
      'icon': Icons.water_drop_rounded,
      'color': AppColors.orange,
      'steps': [
        'Наденьте перчатки',
        'Прижмите рану тканью',
        'Наложите жгут при необходимости',
        'Запишите время',
        'Вызовите скорую',
      ],
    },
    {
      'title': 'Ожоги',
      'icon': Icons.local_fire_department_rounded,
      'color': const Color(0xFFFF9F0A),
      'steps': [
        'Охладите водой 15-20 минут',
        'Снимите украшения',
        'Не прокалывайте пузыри',
        'Стерильная повязка',
        'Скорая при тяжёлых ожогах',
      ],
    },
    {
      'title': 'Переломы',
      'icon': Icons.accessibility_new_rounded,
      'color': AppColors.sky,
      'steps': [
        'Не двигайте кость',
        'Зафиксируйте конечность',
        'Приложите холод',
        'Обезболивающее',
        'Скорая помощь',
      ],
    },
    {
      'title': 'Удушье',
      'icon': Icons.air_rounded,
      'color': AppColors.purple,
      'steps': [
        'Попросите кашлять',
        '5 ударов по спине',
        'Приём Геймлиха',
        'Резкий толчок в живот',
        'Повторяйте',
      ],
    },
    {
      'title': 'Обморок',
      'icon': Icons.person_off_rounded,
      'color': AppColors.mint,
      'steps': [
        'Уложите на спину',
        'Поднимите ноги',
        'Расстегните одежду',
        'Приток воздуха',
        'Если >1 мин → скорая',
      ],
    },
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildPageHeader(context, 'Первая помощь'),
            Expanded(
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: _guides.length,
                itemBuilder: (context, index) {
                  final guide = _guides[index];
                  bool isExpanded = _expandedIndex == index;
                  return FadeSlideIn(
                    delayMs: index * 80,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: SoftCard(
                        onTap: () => setState(
                            () => _expandedIndex = isExpanded ? -1 : index),
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 44,
                                  height: 44,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(14),
                                    color: (guide['color'] as Color)
                                        .withOpacity(0.1),
                                  ),
                                  child: Icon(
                                    guide['icon'] as IconData,
                                    color: guide['color'] as Color,
                                    size: 22,
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Text(
                                    guide['title'] as String,
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.textDark,
                                    ),
                                  ),
                                ),
                                AnimatedRotation(
                                  turns: isExpanded ? 0.5 : 0,
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.easeOutCubic,
                                  child: Icon(
                                    Icons.expand_more_rounded,
                                    color: AppColors.textHint,
                                  ),
                                ),
                              ],
                            ),
                            AnimatedCrossFade(
                              firstChild: const SizedBox.shrink(),
                              secondChild: Padding(
                                padding: const EdgeInsets.only(top: 16),
                                child: Column(
                                  children: List.generate(
                                    (guide['steps'] as List).length,
                                    (i) => Padding(
                                      padding: const EdgeInsets.only(bottom: 10),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            width: 24,
                                            height: 24,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: (guide['color'] as Color)
                                                  .withOpacity(0.1),
                                            ),
                                            child: Center(
                                              child: Text(
                                                '${i + 1}',
                                                style: TextStyle(
                                                  color: guide['color'] as Color,
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Text(
                                              (guide['steps'] as List)[i]
                                                  as String,
                                              style: TextStyle(
                                                color: AppColors.textMedium,
                                                fontSize: 13,
                                                height: 1.4,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              crossFadeState: isExpanded
                                  ? CrossFadeState.showSecond
                                  : CrossFadeState.showFirst,
                              duration: const Duration(milliseconds: 300),
                              sizeCurve: Curves.easeOutCubic,
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
// ============================================================
// SOS PAGE — with improved pulse animation
// ============================================================
class SOSPage extends StatefulWidget {
  const SOSPage({Key? key}) : super(key: key);
  @override
  State<SOSPage> createState() => _SOSPageState();
}
class _SOSPageState extends State<SOSPage> with TickerProviderStateMixin {
  bool _isActivating = false;
  bool _isActivated = false;
  int _countdown = 5;
  Timer? _timer;
  late AnimationController _pulseController;
  late AnimationController _successController;
  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
    _successController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
  }
  void _startCountdown() {
    HapticFeedback.heavyImpact();
    setState(() {
      _isActivating = true;
      _countdown = 5;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      HapticFeedback.mediumImpact();
      setState(() {
        _countdown--;
        if (_countdown <= 0) {
          _timer?.cancel();
          _isActivating = false;
          _isActivated = true;
          _successController.forward();
        }
      });
    });
  }
  void _cancel() {
    _timer?.cancel();
    _successController.reset();
    setState(() {
      _isActivating = false;
      _isActivated = false;
      _countdown = 5;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildPageHeader(context, 'Экстренная помощь'),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (_isActivated) ...[
                    ScaleTransition(
                      scale: CurvedAnimation(
                        parent: _successController,
                        curve: Curves.elasticOut,
                      ),
                      child: Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors.mintSoft,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.mint.withOpacity(0.2),
                              blurRadius: 20,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.check_circle_rounded,
                          color: AppColors.mint,
                          size: 48,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'СИГНАЛ ОТПРАВЛЕН',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppColors.mint,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text('Помощь уже в пути',
                        style: TextStyle(color: AppColors.textLight)),
                    const SizedBox(height: 30),
                    TextButton(
                      onPressed: _cancel,
                      child: Text('Отменить',
                          style: TextStyle(color: AppColors.textLight)),
                    ),
                  ] else ...[
                    SizedBox(
                      width: 250,
                      height: 250,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Multiple expanding rings
                          if (_isActivating) ...[
                            for (int i = 0; i < 3; i++)
                              AnimatedBuilder(
                                animation: _pulseController,
                                builder: (c, _) {
                                  double offset = i * 0.33;
                                  double val =
                                      ((_pulseController.value + offset) % 1.0);
                                  return Container(
                                    width: 250 * (0.65 + 0.35 * val),
                                    height: 250 * (0.65 + 0.35 * val),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: AppColors.coral
                                            .withOpacity(0.3 * (1 - val)),
                                        width: 2,
                                      ),
                                    ),
                                  );
                                },
                              ),
                          ],
                          GestureDetector(
                            onTap: _isActivating ? _cancel : _startCountdown,
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              width: _isActivating ? 170 : 160,
                              height: _isActivating ? 170 : 160,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: const RadialGradient(
                                  colors: [Color(0xFFFF6B6B), Color(0xFFFF4444)],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.coral.withOpacity(0.4),
                                    blurRadius: 30,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  if (_isActivating) ...[
                                    AnimatedSwitcher(
                                      duration:
                                          const Duration(milliseconds: 200),
                                      transitionBuilder:
                                          (child, animation) =>
                                              ScaleTransition(
                                        scale: animation,
                                        child: child,
                                      ),
                                      child: Text(
                                        '$_countdown',
                                        key: ValueKey(_countdown),
                                        style: const TextStyle(
                                          fontSize: 56,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    const Text(
                                      'ОТМЕНА',
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: Colors.white70,
                                        letterSpacing: 2,
                                      ),
                                    ),
                                  ] else
                                    const Text(
                                      'SOS',
                                      style: TextStyle(
                                        fontSize: 36,
                                        fontWeight: FontWeight.w900,
                                        color: Colors.white,
                                        letterSpacing: 3,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 30),
                    Text(
                      _isActivating
                          ? 'Нажмите для отмены'
                          : 'Нажмите для экстренного вызова',
                      style: TextStyle(color: AppColors.textLight, fontSize: 14),
                    ),
                  ],
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    'Экстренные номера',
                    style: TextStyle(
                      color: AppColors.textLight,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _emergencyChip('112', 'Единый'),
                      _emergencyChip('103', 'Скорая'),
                      _emergencyChip('101', 'Пожарная'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
  Widget _emergencyChip(String number, String label) {
    return SoftCard(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Column(
        children: [
          Text(
            number,
            style: const TextStyle(
              color: AppColors.coral,
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(color: AppColors.textLight, fontSize: 10),
          ),
        ],
      ),
    );
  }
  @override
  void dispose() {
    _timer?.cancel();
    _pulseController.dispose();
    _successController.dispose();
    super.dispose();
  }
}
// ============================================================
// DOCTORS PAGE — with search filtering
// ============================================================
class DoctorsPage extends StatefulWidget {
  const DoctorsPage({Key? key}) : super(key: key);
  @override
  State<DoctorsPage> createState() => _DoctorsPageState();
}
class _DoctorsPageState extends State<DoctorsPage> {
  String _selectedSpecialty = 'Все';
  String _searchQuery = '';
  final _specialties = ['Все', 'Терапевт', 'Кардиолог', 'Невролог', 'Хирург'];
  final _doctors = [
    {
      'name': 'Др. Иванова А.С.',
      'specialty': 'Кардиолог',
      'rating': 4.9,
      'experience': '15 лет',
      'distance': '1.2 км',
      'avatar': '👩‍⚕️',
      'available': true,
    },
    {
      'name': 'Др. Петров В.М.',
      'specialty': 'Терапевт',
      'rating': 4.7,
      'experience': '12 лет',
      'distance': '2.5 км',
      'avatar': '👨‍⚕️',
      'available': true,
    },
    {
      'name': 'Др. Сидорова Е.Н.',
      'specialty': 'Невролог',
      'rating': 4.8,
      'experience': '20 лет',
      'distance': '3.1 км',
      'avatar': '👩‍⚕️',
      'available': false,
    },
    {
      'name': 'Др. Козлов И.П.',
      'specialty': 'Хирург',
      'rating': 4.6,
      'experience': '8 лет',
      'distance': '4.0 км',
      'avatar': '👨‍⚕️',
      'available': true,
    },
    {
      'name': 'Др. Новикова М.А.',
      'specialty': 'Кардиолог',
      'rating': 4.9,
      'experience': '18 лет',
      'distance': '1.8 км',
      'avatar': '👩‍⚕️',
      'available': true,
    },
  ];
  List<Map<String, dynamic>> get _filtered {
    var list = _doctors.toList();
    if (_selectedSpecialty != 'Все') {
      list = list.where((d) => d['specialty'] == _selectedSpecialty).toList();
    }
    if (_searchQuery.isNotEmpty) {
      list = list
          .where((d) => (d['name'] as String)
              .toLowerCase()
              .contains(_searchQuery.toLowerCase()))
          .toList();
    }
    return list;
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'КАТАЛОГ',
                  style: TextStyle(
                    fontSize: 10,
                    letterSpacing: 3,
                    color: AppColors.mint.withOpacity(0.7),
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Наши врачи',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textDark,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Icon(Icons.search_rounded, color: AppColors.textHint, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      onChanged: (v) => setState(() => _searchQuery = v),
                      decoration: InputDecoration(
                        hintText: 'Поиск врача...',
                        hintStyle: TextStyle(color: AppColors.textHint),
                        border: InputBorder.none,
                      ),
                      style: const TextStyle(color: AppColors.textDark),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 40,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: _specialties.length,
              itemBuilder: (c, i) {
                bool sel = _selectedSpecialty == _specialties[i];
                return GestureDetector(
                  onTap: () =>
                      setState(() => _selectedSpecialty = _specialties[i]),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    curve: Curves.easeOutCubic,
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: sel ? AppColors.mint : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: sel ? AppColors.mint : AppColors.border,
                      ),
                      boxShadow: sel
                          ? [
                              BoxShadow(
                                color: AppColors.mint.withOpacity(0.2),
                                blurRadius: 8,
                              ),
                            ]
                          : [],
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      _specialties[i],
                      style: TextStyle(
                        color: sel ? Colors.white : AppColors.textMedium,
                        fontSize: 12,
                        fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: _filtered.isEmpty
                  ? Center(
                      key: const ValueKey('empty'),
                      child: Text(
                        'Врачи не найдены',
                        style: TextStyle(color: AppColors.textLight),
                      ),
                    )
                  : ListView.builder(
                      key: ValueKey(_selectedSpecialty + _searchQuery),
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: _filtered.length,
                      itemBuilder: (c, i) {
                        final doc = _filtered[i];
                        return FadeSlideIn(
                          delayMs: i * 80,
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: SoftCard(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  Container(
                                    width: 56,
                                    height: 56,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(16),
                                      gradient: LinearGradient(
                                        colors: [
                                          AppColors.mint.withOpacity(0.1),
                                          AppColors.sky.withOpacity(0.1),
                                        ],
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        doc['avatar'] as String,
                                        style: const TextStyle(fontSize: 28),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          doc['name'] as String,
                                          style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.textDark,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          '${doc['specialty']} · ${doc['experience']}',
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: AppColors.textLight,
                                          ),
                                        ),
                                        const SizedBox(height: 6),
                                        Row(
                                          children: [
                                            const Icon(
                                              Icons.star_rounded,
                                              color: AppColors.orange,
                                              size: 14,
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              '${doc['rating']}',
                                              style: const TextStyle(
                                                color: AppColors.orange,
                                                fontSize: 12,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                            const SizedBox(width: 12),
                                            Icon(
                                              Icons.location_on_rounded,
                                              color: AppColors.textHint,
                                              size: 14,
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              doc['distance'] as String,
                                              style: TextStyle(
                                                color: AppColors.textHint,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 14,
                                      vertical: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      color: (doc['available'] as bool)
                                          ? AppColors.mintSoft
                                          : AppColors.bg,
                                      border: Border.all(
                                        color: (doc['available'] as bool)
                                            ? AppColors.mint.withOpacity(0.3)
                                            : AppColors.border,
                                      ),
                                    ),
                                    child: Text(
                                      (doc['available'] as bool)
                                          ? 'Записаться'
                                          : 'Занят',
                                      style: TextStyle(
                                        color: (doc['available'] as bool)
                                            ? AppColors.mint
                                            : AppColors.textLight,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
// ============================================================
// AI CHAT PAGE — with typing animation
// ============================================================
class AIChatPage extends StatefulWidget {
  const AIChatPage({Key? key}) : super(key: key);
  @override
  State<AIChatPage> createState() => _AIChatPageState();
}
class _AIChatPageState extends State<AIChatPage> {
  final _textController = TextEditingController();
  final _scrollController = ScrollController();
  bool _isTyping = false;
  final List<Map<String, dynamic>> _messages = [
    {
      'text': 'Здравствуйте! Я ваш AI-медицинский ассистент. Чем могу помочь? 👋',
      'isBot': true,
    },
  ];
  final _suggestions = [
    'Какой у меня пульс?',
    'Болит голова',
    'Нормальное давление',
    'Советы по сну',
  ];
  void _sendMessage(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      _messages.add({'text': text, 'isBot': false});
      _isTyping = true;
    });
    _textController.clear();
    _scrollToBottom();
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (!mounted) return;
      setState(() {
        _messages.add({
          'text': _getAIResponse(text.toLowerCase()),
          'isBot': true,
        });
        _isTyping = false;
      });
      _scrollToBottom();
    });
  }
  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }
  String _getAIResponse(String text) {
    if (text.contains('пульс') || text.contains('сердц')) {
      return 'Нормальный пульс в покое — 60-100 уд/мин. Используйте сканер пульса в приложении для точного измерения! 📊';
    }
    if (text.contains('давлен')) {
      return 'Нормальное давление: 120/80 мм рт.ст. Повышенное (>140/90) требует консультации врача. 📊';
    }
    if (text.contains('голов')) {
      return 'При головной боли: пейте воду, отдохните, проветрите помещение. При частых болях → невролог. 🧠';
    }
    if (text.contains('температур')) {
      return 'Норма: 36.1-37.2°C. При 38.5+ примите жаропонижающее. При 39.5+ → скорая (103). 🌡️';
    }
    if (text.contains('сон')) {
      return 'Спите 7-9 часов, без экранов за час до сна, температура 18-22°C. Попробуйте дыхательную гимнастику! 😴';
    }
    return 'Спасибо за вопрос! Для точной консультации обратитесь к специалистам в разделе «Врачи». 💬';
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: AppColors.textDark.withOpacity(0.03),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    gradient: const LinearGradient(
                      colors: [AppColors.mint, AppColors.sky],
                    ),
                  ),
                  child: const Icon(
                    Icons.psychology_rounded,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'AI Консультант',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textDark,
                      ),
                    ),
                    Row(
                      children: [
                        _PulsingDot(color: AppColors.mint),
                        const SizedBox(width: 6),
                        Text(
                          'Онлайн',
                          style: TextStyle(
                            color: AppColors.textLight,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Messages
          Expanded(
            child: Container(
              color: AppColors.bg,
              child: ListView.builder(
                controller: _scrollController,
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.all(20),
                itemCount: _messages.length + (_isTyping ? 1 : 0),
                itemBuilder: (c, i) {
                  if (i == _messages.length && _isTyping) {
                    return _buildTyping();
                  }
                  final msg = _messages[i];
                  final isBot = msg['isBot'] as bool;
                  return FadeSlideIn(
                    delayMs: 0,
                    offset: Offset(isBot ? -20 : 20, 0),
                    child: Align(
                      alignment:
                          isBot ? Alignment.centerLeft : Alignment.centerRight,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(14),
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width * 0.75,
                        ),
                        decoration: BoxDecoration(
                          color: isBot ? Colors.white : AppColors.mint,
                          borderRadius: BorderRadius.only(
                            topLeft: const Radius.circular(18),
                            topRight: const Radius.circular(18),
                            bottomLeft: Radius.circular(isBot ? 4 : 18),
                            bottomRight: Radius.circular(isBot ? 18 : 4),
                          ),
                          border: isBot
                              ? Border.all(color: AppColors.border)
                              : null,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.textDark.withOpacity(0.04),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Text(
                          msg['text'] as String,
                          style: TextStyle(
                            color: isBot ? AppColors.textDark : Colors.white,
                            fontSize: 14,
                            height: 1.5,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          // Suggestions
          if (_messages.length <= 2)
            Container(
              color: AppColors.bg,
              height: 40,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: _suggestions.length,
                itemBuilder: (c, i) => GestureDetector(
                  onTap: () => _sendMessage(_suggestions[i]),
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: AppColors.mintSoft,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppColors.mint.withOpacity(0.2),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      _suggestions[i],
                      style: const TextStyle(
                        color: AppColors.mint,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          if (_messages.length <= 2) const SizedBox(height: 12),
          // Input
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: AppColors.textDark.withOpacity(0.04),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: AppColors.bg,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: TextField(
                        controller: _textController,
                        decoration: InputDecoration(
                          hintText: 'Задайте вопрос...',
                          hintStyle: TextStyle(color: AppColors.textHint),
                          border: InputBorder.none,
                        ),
                        style: const TextStyle(color: AppColors.textDark),
                        onSubmitted: _sendMessage,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: () => _sendMessage(_textController.text),
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: const LinearGradient(
                          colors: [AppColors.mint, AppColors.sky],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.mint.withOpacity(0.3),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.send_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  Widget _buildTyping() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(18),
            topRight: Radius.circular(18),
            bottomRight: Radius.circular(18),
            bottomLeft: Radius.circular(4),
          ),
          border: Border.all(color: AppColors.border),
        ),
        child: _TypingIndicator(),
      ),
    );
  }
  @override
  void dispose() {
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}
// ============================================================
// TYPING INDICATOR — animated dots
// ============================================================
class _TypingIndicator extends StatefulWidget {
  @override
  State<_TypingIndicator> createState() => _TypingIndicatorState();
}
class _TypingIndicatorState extends State<_TypingIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
  }
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        return AnimatedBuilder(
          animation: _controller,
          builder: (context, _) {
            double delay = i * 0.2;
            double val = ((_controller.value - delay) % 1.0);
            double bounce = val < 0.5 ? val * 2 : (1 - val) * 2;
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.mint.withOpacity(0.3 + 0.5 * bounce),
              ),
              transform: Matrix4.translationValues(0, -4 * bounce, 0),
            );
          },
        );
      }),
    );
  }
}
// ============================================================
// PROFILE PAGE
// ============================================================
class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final displayName = user?.displayName ?? 'Пользователь';
    final email = user?.email ?? 'user@pulsecheck.ai';
    return SafeArea(
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            FadeSlideIn(
              delayMs: 0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ЛИЧНЫЙ КАБИНЕТ',
                    style: TextStyle(
                      fontSize: 10,
                      letterSpacing: 3,
                      color: AppColors.mint.withOpacity(0.7),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Мой профиль',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textDark,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Profile card
            FadeSlideIn(
              delayMs: 100,
              child: SoftCard(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [AppColors.mint, AppColors.sky],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.mint.withOpacity(0.3),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          displayName.isNotEmpty
                              ? displayName[0].toUpperCase()
                              : 'U',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            displayName,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textDark,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            email,
                            style: TextStyle(
                              fontSize: 13,
                              color: AppColors.textLight,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Stats from Firebase
            FadeSlideIn(
              delayMs: 200,
              child: StreamBuilder<QuerySnapshot>(
                stream: DatabaseService().getPulseHistory(),
                builder: (context, snapshot) {
                  int totalMeasurements = 0;
                  int avgPulse = 0;
                  if (snapshot.hasData && snapshot.data!.docs.isNotEmpty) {
                    totalMeasurements = snapshot.data!.docs.length;
                    int sum = 0;
                    for (var doc in snapshot.data!.docs) {
                      sum += (doc['bpm'] as num).toInt();
                    }
                    avgPulse = (sum / totalMeasurements).round();
                  }
                  return Row(
                    children: [
                      Expanded(
                        child: _statCard('Измерений', '$totalMeasurements', AppColors.sky),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _statCard(
                          'Ср. пульс',
                          avgPulse > 0 ? '$avgPulse' : '--',
                          AppColors.coral,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _statCard('Здоровье', 'A+', AppColors.mint),
                      ),
                    ],
                  );
                },
              ),
            ),
            const SizedBox(height: 24),
            FadeSlideIn(
              delayMs: 300,
              child: const Text(
                'История измерений',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textDark,
                ),
              ),
            ),
            const SizedBox(height: 12),
            StreamBuilder<QuerySnapshot>(
              stream: DatabaseService().getPulseHistory(),
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return FadeSlideIn(
                    delayMs: 350,
                    child: SoftCard(
                      padding: const EdgeInsets.all(30),
                      child: Center(
                        child: Text(
                          'Пока нет измерений\nСделайте первый скан пульса!',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppColors.textLight),
                        ),
                      ),
                    ),
                  );
                }
                final docs = snapshot.data!.docs.take(10).toList();
                return Column(
                  children: docs.asMap().entries.map((entry) {
                    final index = entry.key;
                    final doc = entry.value;
                    final data = doc.data() as Map<String, dynamic>;
                    final bpm = (data['bpm'] as num?)?.toInt() ?? 0;
                    final min = (data['min'] as num?)?.toInt() ?? 0;
                    final max = (data['max'] as num?)?.toInt() ?? 0;
                    final timestamp = data['timestamp'] as Timestamp?;
                    final dateStr = timestamp != null
                        ? '${timestamp.toDate().day}.${timestamp.toDate().month} ${timestamp.toDate().hour}:${timestamp.toDate().minute.toString().padLeft(2, '0')}'
                        : 'Сейчас';
                    return FadeSlideIn(
                      delayMs: 350 + index * 60,
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: SoftCard(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  color: AppColors.coralLight,
                                ),
                                child: const Icon(
                                  Icons.favorite_rounded,
                                  color: AppColors.coral,
                                  size: 18,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      'Пульс',
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.textDark,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      '$dateStr · ↓$min ↑$max',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: AppColors.textHint,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                '$bpm BPM',
                                style: const TextStyle(
                                  color: AppColors.coral,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
            const SizedBox(height: 24),
            FadeSlideIn(
              delayMs: 500,
              child: const Text(
                'Настройки',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textDark,
                ),
              ),
            ),
            const SizedBox(height: 12),
            FadeSlideIn(
              delayMs: 550,
              child: _settingsItem(Icons.notifications_rounded, 'Уведомления', AppColors.sky),
            ),
            FadeSlideIn(
              delayMs: 600,
              child: _settingsItem(Icons.language_rounded, 'Язык', AppColors.mint),
            ),
            FadeSlideIn(
              delayMs: 650,
              child: _settingsItem(Icons.dark_mode_rounded, 'Тема', AppColors.purple),
            ),
            FadeSlideIn(
              delayMs: 700,
              child: _settingsItem(Icons.info_outline_rounded, 'О приложении', AppColors.orange),
            ),
            // Logout
            const SizedBox(height: 8),
            FadeSlideIn(
              delayMs: 750,
              child: GestureDetector(
                onTap: () => _showLogoutDialog(context),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.coralLight,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.coral.withOpacity(0.2)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColors.coral.withOpacity(0.15),
                        ),
                        child: const Icon(
                          Icons.logout_rounded,
                          color: AppColors.coral,
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Text(
                          'Выйти из аккаунта',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppColors.coral,
                          ),
                        ),
                      ),
                      const Icon(
                        Icons.chevron_right_rounded,
                        color: AppColors.coral,
                        size: 20,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 100),
          ],
        ),
      ),
    );
  }
  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text(
          'Выход из аккаунта',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 18,
            color: AppColors.textDark,
          ),
        ),
        content: Text(
          'Вы уверены, что хотите выйти?',
          style: TextStyle(color: AppColors.textMedium),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Отмена',
              style: TextStyle(color: AppColors.textLight),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await FirebaseAuth.instance.signOut();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.coral,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              'Выйти',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
  Widget _statCard(String label, String value, Color color) {
    return SoftCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOutCubic,
            builder: (context, val, child) {
              return Opacity(opacity: val, child: child);
            },
            child: Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w800,
                color: color,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              color: AppColors.textLight,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
  Widget _settingsItem(IconData icon, String label, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SoftCard(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: color.withOpacity(0.1),
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textDark,
                ),
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: AppColors.textHint, size: 20),
          ],
        ),
      ),
    );
  }
}
// ============================================================
// SHARED HELPERS
// ============================================================
Widget _buildPageHeader(BuildContext context, String title) {
  return Padding(
    padding: const EdgeInsets.all(20),
    child: Row(
      children: [
        _backButton(context),
        const SizedBox(width: 16),
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.textDark,
          ),
        ),
      ],
    ),
  );
}
Widget _backButton(BuildContext context) {
  return GestureDetector(
    onTap: () => Navigator.pop(context),
    child: Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
        boxShadow: [
          BoxShadow(
            color: AppColors.textDark.withOpacity(0.04),
            blurRadius: 8,
          ),
        ],
      ),
      child: const Icon(
        Icons.arrow_back_ios_new_rounded,
        size: 16,
        color: AppColors.textMedium,
      ),
    ),
  );
}